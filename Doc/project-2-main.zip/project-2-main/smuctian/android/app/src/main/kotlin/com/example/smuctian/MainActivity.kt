package com.example.smuctian

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
