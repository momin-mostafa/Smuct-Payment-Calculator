import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:get/get.dart';
import 'package:smuctian/core/firebase_auth_services/auth_binding.dart';
import 'package:smuctian/core/login/login_wrapper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const BindingWrapper());
}

class BindingWrapper extends StatelessWidget {
  const BindingWrapper({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      initialBinding: AuthBinding(),
      home: const SafeArea(child: LoginWrapper()),
    );
  }
}
