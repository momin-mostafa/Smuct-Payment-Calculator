import 'package:get/get.dart';
import 'package:smuctian/core/firebase_auth_services/firebase_auth_services.dart';

class AuthBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthController>(() => AuthController());
  }
}
