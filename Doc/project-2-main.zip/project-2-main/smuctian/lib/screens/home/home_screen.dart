import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:smuctian/core/firebase_auth_services/firebase_auth_services.dart';
import 'package:smuctian/screens/fee_calculator/fee_calculator.dart';

class HomePage extends GetWidget<AuthController> {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
            title: const Text('Home page'),
            centerTitle: true,
          ),
          body: Column(children: [
            TextButton(
              onPressed: () {
                Get.to(PaymentPage());
              },
              child: const Text('fee calculator.'),
            ),
            TextButton(
              onPressed: () {
                controller.signOut();
              },
              child: const Text('sign out'),
            ),
          ])),
    );
  }
}
