import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:smuctian/core/firebase_auth_services/firebase_auth_services.dart';
import 'package:smuctian/screens/custom_widgets/custom_widgets_login.dart';
import 'package:smuctian/screens/registration/registration_screen.dart';

class LoginPage extends GetWidget<AuthController> {
  LoginPage({Key? key}) : super(key: key);

  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Login Screen"),
        centerTitle: true,
      ),
      body: SizedBox(
        height: size.height,
        child: ListView(
          children: [
            SizedBox(
              height: size.height / 3,
              width: size.width / .5,
              child: Card(
                elevation: 8,
                child: Image.asset('images/login_screen_background_image.png'),
              ),
            ),
            customTextFiledForLoginPage(
              controller: emailController,
              lable: 'Email',
              hintText: 'abc@example.com',
              inputType: TextInputType.emailAddress,
              obscurity: false,
            ),
            customTextFiledForLoginPage(
              controller: passwordController,
              lable: 'Password',
              hintText: '',
              inputType: TextInputType.text,
              obscurity: true,
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () {
                controller
                    .login(
                        email: emailController.value.text.trim(),
                        password: passwordController.value.text.trim())
                    .catchError((onError) {
                  Get.snackbar('LoginPage Error',
                      "looks like this went wrong :\n$onError");
                });
              },
              child: const Text("Login"),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.to(RegistrationPage());
        },
        child: const Text("Register"),
      ),
    );
  }
}
